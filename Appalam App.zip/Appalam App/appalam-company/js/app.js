/* ===== Appalam Company - Main Application JS ===== */

const STORAGE_KEYS = {
  customers: 'appalam_customers',
  invoices: 'appalam_invoices',
  products: 'appalam_products',
  contactMessages: 'appalam_messages'
};

const COMPANY = {
  name: 'APPALAM MART',
  tagline: 'Premium Appalam Manufacturing Company',
  address: '123, Industrial Estate, Madurai, Tamil Nadu - 625001',
  phone: '+91 98765 43210',
  email: 'info@appalammart.com',
  gstin: '33AABCU9603R1ZM',
  pan: 'AABCU9603R'
};

const DEFAULT_PRODUCTS = [
  { id: 'P001', name: 'Urad Appalam', category: 'Classic', price: 120, stock: 500, unit: 'Pack', emoji: '🫓' },
  { id: 'P002', name: 'Pepper Appalam', category: 'Spiced', price: 150, stock: 350, unit: 'Pack', emoji: '🌶️' },
  { id: 'P003', name: 'Rice Appalam', category: 'Classic', price: 100, stock: 600, unit: 'Pack', emoji: '🍚' },
  { id: 'P004', name: 'Garlic Appalam', category: 'Flavored', price: 140, stock: 280, unit: 'Pack', emoji: '🧄' },
  { id: 'P005', name: 'Jeera Appalam', category: 'Flavored', price: 130, stock: 420, unit: 'Pack', emoji: '🌿' },
  { id: 'P006', name: 'Mini Appalam', category: 'Special', price: 90, stock: 750, unit: 'Pack', emoji: '⭐' },
  { id: 'P007', name: 'Masala Appalam', category: 'Spiced', price: 160, stock: 200, unit: 'Pack', emoji: '🔥' },
  { id: 'P008', name: 'Plain Appalam (Bulk)', category: 'Wholesale', price: 85, stock: 1000, unit: 'Kg', emoji: '📦' }
];

const DEFAULT_CUSTOMERS = [
  { id: 'C1001', name: 'Ravi Traders', phone: '9876543210', email: 'ravi@traders.com', city: 'Chennai', gstin: '33AAAAA0000A1Z5', address: '12, Anna Salai, Chennai' },
  { id: 'C1002', name: 'Sri Foods', phone: '9123456789', email: 'info@srifood.com', city: 'Madurai', gstin: '33BBBBB0000B1Z5', address: '45, Main Road, Madurai' },
  { id: 'C1003', name: 'Kumar Wholesale', phone: '9988776655', email: 'kumar@wholesale.in', city: 'Coimbatore', gstin: '33CCCCC0000C1Z5', address: '78, Gandhipuram, Coimbatore' }
];

/* ===== Utility Functions ===== */
function getData(key, defaults = []) {
  const stored = localStorage.getItem(key);
  if (stored) {
    try { return JSON.parse(stored); } catch { return defaults; }
  }
  return defaults;
}

function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

function formatCurrency(amount) {
  return '₹' + Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function generateId(prefix) {
  return prefix + Date.now().toString(36).toUpperCase();
}

function generateInvoiceNumber() {
  const invoices = getData(STORAGE_KEYS.invoices, []);
  const num = invoices.length + 1;
  const year = new Date().getFullYear();
  return `INV-${year}-${String(num).padStart(4, '0')}`;
}

function showToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle';
  toast.innerHTML = `<i class="fa-solid fa-${icon}"></i> ${message}`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function setActiveNav() {
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav ul li a').forEach(link => {
    link.classList.toggle('active', link.getAttribute('href') === current);
  });
}

function initMobileMenu() {
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('nav ul');
  if (toggle && menu) {
    toggle.addEventListener('click', () => menu.classList.toggle('open'));
  }
}

function initProducts() {
  if (!localStorage.getItem(STORAGE_KEYS.products)) {
    saveData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  }
}

function initCustomers() {
  if (!localStorage.getItem(STORAGE_KEYS.customers)) {
    saveData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  }
}

/* ===== Home Page ===== */
function initHomePage() {
  const stats = document.querySelectorAll('.stat-item h3[data-count]');
  stats.forEach(stat => {
    const target = parseInt(stat.dataset.count);
    let current = 0;
    const step = Math.ceil(target / 50);
    const timer = setInterval(() => {
      current += step;
      if (current >= target) { current = target; clearInterval(timer); }
      stat.textContent = current.toLocaleString('en-IN') + (stat.dataset.suffix || '');
    }, 30);
  });
}

/* ===== Products Page ===== */
function initProductsPage() {
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  const grid = document.getElementById('productGrid');
  const searchInput = document.getElementById('productSearch');
  const categoryFilter = document.getElementById('categoryFilter');

  if (!grid) return;

  function renderProducts(list) {
    grid.innerHTML = list.map(p => `
      <div class="product" data-category="${p.category}">
        <div class="product-img">${p.emoji || '🫓'}</div>
        <div class="product-body">
          <span class="category">${p.category}</span>
          <h3>${p.name}</h3>
          <div class="price">${formatCurrency(p.price)} / ${p.unit}</div>
          <div class="stock ${p.stock < 100 ? 'low' : ''}">
            ${p.stock < 100 ? '⚠️ Low Stock: ' : 'In Stock: '}${p.stock} ${p.unit}s
          </div>
          <button class="btn btn-primary btn-sm" onclick="addToInvoice('${p.id}')">
            <i class="fa-solid fa-cart-plus"></i> Add to Bill
          </button>
        </div>
      </div>
    `).join('');
  }

  renderProducts(products);

  if (searchInput) {
    searchInput.addEventListener('input', filterProducts);
  }
  if (categoryFilter) {
    categoryFilter.addEventListener('change', filterProducts);
  }

  function filterProducts() {
    const query = (searchInput?.value || '').toLowerCase();
    const category = categoryFilter?.value || '';
    const filtered = products.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(query) || p.category.toLowerCase().includes(query);
      const matchCategory = !category || p.category === category;
      return matchSearch && matchCategory;
    });
    renderProducts(filtered);
  }
}

function addToInvoice(productId) {
  sessionStorage.setItem('addProductId', productId);
  window.location.href = 'invoice.html';
}

/* ===== Invoice / Billing Page ===== */
let invoiceItems = [];

function initInvoicePage() {
  initProducts();
  initCustomers();
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  const customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);

  const customerSelect = document.getElementById('customerSelect');
  const invoiceDate = document.getElementById('invoiceDate');
  const invoiceNumber = document.getElementById('invoiceNumber');

  if (invoiceDate) invoiceDate.value = new Date().toISOString().split('T')[0];
  if (invoiceNumber) invoiceNumber.value = generateInvoiceNumber();

  if (customerSelect) {
    customerSelect.innerHTML = '<option value="">-- Select Customer --</option>' +
      customers.map(c => `<option value="${c.id}">${c.name} (${c.city})</option>`).join('');
  }

  const addProductId = sessionStorage.getItem('addProductId');
  if (addProductId) {
    sessionStorage.removeItem('addProductId');
    const product = products.find(p => p.id === addProductId);
    if (product) addInvoiceItem(product);
  } else {
    addInvoiceItem();
  }

  renderInvoicePreview();
  loadInvoiceHistory();
}

function addInvoiceItem(product = null) {
  invoiceItems.push({
    productId: product?.id || '',
    name: product?.name || '',
    qty: product ? 1 : 0,
    price: product?.price || 0,
    gst: 18
  });
  renderInvoiceItems();
}

function removeInvoiceItem(index) {
  invoiceItems.splice(index, 1);
  renderInvoiceItems();
}

function renderInvoiceItems() {
  const tbody = document.getElementById('invoiceItemsBody');
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  if (!tbody) return;

  tbody.innerHTML = invoiceItems.map((item, i) => `
    <tr>
      <td>
        <select onchange="updateItemProduct(${i}, this.value)" class="item-product">
          <option value="">Select Product</option>
          ${products.map(p => `<option value="${p.id}" ${item.productId === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
        </select>
      </td>
      <td><input type="number" value="${item.qty}" min="1" onchange="updateItem(${i}, 'qty', this.value)"></td>
      <td><input type="number" value="${item.price}" min="0" step="0.01" onchange="updateItem(${i}, 'price', this.value)"></td>
      <td>${formatCurrency(item.qty * item.price)}</td>
      <td>
        <button class="btn btn-danger btn-icon btn-sm" onclick="removeInvoiceItem(${i})">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');

  updateInvoiceSummary();
  renderInvoicePreview();
}

function updateItemProduct(index, productId) {
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  const product = products.find(p => p.id === productId);
  if (product) {
    invoiceItems[index].productId = product.id;
    invoiceItems[index].name = product.name;
    invoiceItems[index].price = product.price;
    if (!invoiceItems[index].qty) invoiceItems[index].qty = 1;
  }
  renderInvoiceItems();
}

function updateItem(index, field, value) {
  invoiceItems[index][field] = parseFloat(value) || 0;
  updateInvoiceSummary();
  renderInvoicePreview();
}

function updateInvoiceSummary() {
  const subtotal = invoiceItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
  const cgst = subtotal * 0.09;
  const sgst = subtotal * 0.09;
  const total = subtotal + cgst + sgst;

  const el = id => document.getElementById(id);
  if (el('summarySubtotal')) el('summarySubtotal').textContent = formatCurrency(subtotal);
  if (el('summaryCGST')) el('summaryCGST').textContent = formatCurrency(cgst);
  if (el('summarySGST')) el('summarySGST').textContent = formatCurrency(sgst);
  if (el('summaryTotal')) el('summaryTotal').textContent = formatCurrency(total);
}

function renderInvoicePreview() {
  const preview = document.getElementById('invoicePreview');
  if (!preview) return;

  const customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  const customerId = document.getElementById('customerSelect')?.value;
  const customer = customers.find(c => c.id === customerId);
  const invNum = document.getElementById('invoiceNumber')?.value || generateInvoiceNumber();
  const invDate = document.getElementById('invoiceDate')?.value || new Date().toISOString().split('T')[0];

  const subtotal = invoiceItems.reduce((sum, item) => sum + (item.qty * item.price), 0);
  const cgst = subtotal * 0.09;
  const sgst = subtotal * 0.09;
  const total = subtotal + cgst + sgst;

  preview.innerHTML = `
    <div class="inv-header">
      <div class="company-info">
        <h2>${COMPANY.name}</h2>
        <p>${COMPANY.address}</p>
        <p>Phone: ${COMPANY.phone} | Email: ${COMPANY.email}</p>
        <p><strong>GSTIN:</strong> ${COMPANY.gstin} | <strong>PAN:</strong> ${COMPANY.pan}</p>
      </div>
      <div class="inv-meta">
        <h3>TAX INVOICE</h3>
        <p><strong>Invoice No:</strong> ${invNum}</p>
        <p><strong>Date:</strong> ${invDate}</p>
      </div>
    </div>
    <div class="customer-info">
      <p><strong>Bill To:</strong></p>
      <p>${customer ? customer.name : '— Select Customer —'}</p>
      ${customer ? `<p>${customer.address}, ${customer.city}</p><p>Phone: ${customer.phone} | GSTIN: ${customer.gstin || 'N/A'}</p>` : ''}
    </div>
    <table class="inv-table">
      <thead>
        <tr><th>#</th><th>Product</th><th>Qty</th><th>Rate</th><th>Amount</th></tr>
      </thead>
      <tbody>
        ${invoiceItems.length ? invoiceItems.map((item, i) => `
          <tr>
            <td>${i + 1}</td>
            <td>${item.name || '—'}</td>
            <td>${item.qty}</td>
            <td>${formatCurrency(item.price)}</td>
            <td>${formatCurrency(item.qty * item.price)}</td>
          </tr>
        `).join('') : '<tr><td colspan="5" style="text-align:center;color:#999;">No items added</td></tr>'}
      </tbody>
    </table>
    <div class="inv-totals">
      <div class="row"><span>Subtotal</span><span>${formatCurrency(subtotal)}</span></div>
      <div class="row"><span>CGST (9%)</span><span>${formatCurrency(cgst)}</span></div>
      <div class="row"><span>SGST (9%)</span><span>${formatCurrency(sgst)}</span></div>
      <div class="row grand-total"><span>Grand Total</span><span>${formatCurrency(total)}</span></div>
    </div>
    <div class="inv-footer">
      <p>Thank you for your business! | Terms: Payment due within 15 days.</p>
      <p>This is a computer-generated invoice.</p>
    </div>
  `;
}

function generateBill() {
  const customerId = document.getElementById('customerSelect')?.value;
  if (!customerId) { showToast('Please select a customer', 'error'); return; }
  if (!invoiceItems.length || invoiceItems.every(i => !i.name)) {
    showToast('Please add at least one product', 'error');
    return;
  }

  const customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  const customer = customers.find(c => c.id === customerId);
  const subtotal = invoiceItems.reduce((sum, item) => sum + (item.qty * item.price), 0);

  const invoice = {
    id: generateId('INV'),
    number: document.getElementById('invoiceNumber')?.value || generateInvoiceNumber(),
    date: document.getElementById('invoiceDate')?.value,
    customerId,
    customerName: customer.name,
    items: [...invoiceItems],
    subtotal,
    cgst: subtotal * 0.09,
    sgst: subtotal * 0.09,
    total: subtotal * 1.18,
    status: 'Paid'
  };

  const invoices = getData(STORAGE_KEYS.invoices, []);
  invoices.push(invoice);
  saveData(STORAGE_KEYS.invoices, invoices);

  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  invoiceItems.forEach(item => {
    const prod = products.find(p => p.id === item.productId);
    if (prod) prod.stock = Math.max(0, prod.stock - item.qty);
  });
  saveData(STORAGE_KEYS.products, products);

  showToast(`Invoice ${invoice.number} generated successfully!`);
  renderInvoicePreview();
  loadInvoiceHistory();

  document.getElementById('invoiceNumber').value = generateInvoiceNumber();
}

function printInvoice() {
  window.print();
}

function downloadInvoicePDF() {
  const preview = document.getElementById('invoicePreview');
  if (!preview) return;

  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <!DOCTYPE html><html><head><title>Invoice</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 20px; }
      table { width: 100%; border-collapse: collapse; margin: 15px 0; }
      th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
      th { background: #1f2937; color: white; }
      .inv-header { display: flex; justify-content: space-between; border-bottom: 2px solid #e65100; padding-bottom: 15px; margin-bottom: 15px; }
      .inv-totals { float: right; width: 280px; }
      .inv-totals .row { display: flex; justify-content: space-between; padding: 4px 0; }
      .grand-total { font-size: 18px; font-weight: bold; color: #e65100; border-top: 2px solid #333; padding-top: 8px; }
      .inv-footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
    </style></head><body>${preview.innerHTML}</body></html>
  `);
  printWindow.document.close();
  printWindow.print();
}

function loadInvoiceHistory() {
  const tbody = document.getElementById('invoiceHistoryBody');
  if (!tbody) return;

  const invoices = getData(STORAGE_KEYS.invoices, []).reverse();
  tbody.innerHTML = invoices.length ? invoices.map(inv => `
    <tr>
      <td>${inv.number}</td>
      <td>${inv.date}</td>
      <td>${inv.customerName}</td>
      <td>${formatCurrency(inv.total)}</td>
      <td><span class="badge badge-success">${inv.status}</span></td>
      <td>
        <button class="btn btn-secondary btn-sm" onclick="viewInvoice('${inv.id}')">
          <i class="fa-solid fa-eye"></i> View
        </button>
      </td>
    </tr>
  `).join('') : '<tr><td colspan="6" style="text-align:center;">No invoices yet</td></tr>';
}

function viewInvoice(id) {
  const invoices = getData(STORAGE_KEYS.invoices, []);
  const inv = invoices.find(i => i.id === id);
  if (!inv) return;

  invoiceItems = [...inv.items];
  document.getElementById('customerSelect').value = inv.customerId;
  document.getElementById('invoiceNumber').value = inv.number;
  document.getElementById('invoiceDate').value = inv.date;
  renderInvoiceItems();
  showToast('Invoice loaded for viewing', 'info');
}

/* ===== Customer Management ===== */
function initCustomersPage() {
  initCustomers();
  renderCustomerTable();
}

function renderCustomerTable(filter = '') {
  const tbody = document.getElementById('customerTableBody');
  if (!tbody) return;

  let customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  if (filter) {
    const q = filter.toLowerCase();
    customers = customers.filter(c =>
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.city.toLowerCase().includes(q)
    );
  }

  tbody.innerHTML = customers.map(c => `
    <tr>
      <td>${c.id}</td>
      <td>${c.name}</td>
      <td>${c.phone}</td>
      <td>${c.email || '—'}</td>
      <td>${c.city}</td>
      <td>${c.gstin || '—'}</td>
      <td class="table-actions">
        <button class="btn btn-secondary btn-icon btn-sm" onclick="editCustomer('${c.id}')" title="Edit">
          <i class="fa-solid fa-pen"></i>
        </button>
        <button class="btn btn-danger btn-icon btn-sm" onclick="deleteCustomer('${c.id}')" title="Delete">
          <i class="fa-solid fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function saveCustomer(e) {
  e.preventDefault();
  const form = e.target;
  const editId = form.dataset.editId;

  const customer = {
    id: editId || generateId('C'),
    name: form.customerName.value.trim(),
    phone: form.customerPhone.value.trim(),
    email: form.customerEmail.value.trim(),
    city: form.customerCity.value.trim(),
    gstin: form.customerGstin.value.trim(),
    address: form.customerAddress.value.trim()
  };

  if (!customer.name || !customer.phone) {
    showToast('Name and phone are required', 'error');
    return;
  }

  let customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  if (editId) {
    const idx = customers.findIndex(c => c.id === editId);
    if (idx !== -1) customers[idx] = customer;
    showToast('Customer updated successfully');
  } else {
    customers.push(customer);
    showToast('Customer added successfully');
  }

  saveData(STORAGE_KEYS.customers, customers);
  form.reset();
  delete form.dataset.editId;
  document.getElementById('customerFormTitle').textContent = 'Add New Customer';
  renderCustomerTable();
}

function editCustomer(id) {
  const customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  const customer = customers.find(c => c.id === id);
  if (!customer) return;

  const form = document.getElementById('customerForm');
  form.customerName.value = customer.name;
  form.customerPhone.value = customer.phone;
  form.customerEmail.value = customer.email || '';
  form.customerCity.value = customer.city;
  form.customerGstin.value = customer.gstin || '';
  form.customerAddress.value = customer.address || '';
  form.dataset.editId = id;
  document.getElementById('customerFormTitle').textContent = 'Edit Customer';
  form.scrollIntoView({ behavior: 'smooth' });
}

function deleteCustomer(id) {
  if (!confirm('Are you sure you want to delete this customer?')) return;
  let customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);
  customers = customers.filter(c => c.id !== id);
  saveData(STORAGE_KEYS.customers, customers);
  renderCustomerTable();
  showToast('Customer deleted', 'info');
}

function searchCustomers() {
  const query = document.getElementById('customerSearch')?.value || '';
  renderCustomerTable(query);
}

/* ===== Contact Page ===== */
function initContactPage() {
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const messages = getData(STORAGE_KEYS.contactMessages, []);
      messages.push({
        id: generateId('MSG'),
        name: form.contactName.value,
        email: form.contactEmail.value,
        phone: form.contactPhone.value,
        subject: form.contactSubject.value,
        message: form.contactMessage.value,
        date: new Date().toISOString()
      });
      saveData(STORAGE_KEYS.contactMessages, messages);
      form.reset();
      showToast('Message sent successfully! We will contact you soon.');
    });
  }
}

/* ===== Admin Dashboard ===== */
const ADMIN_CREDENTIALS = { username: 'admin', password: 'admin123' };

function initAdminPage() {
  const overlay = document.getElementById('loginOverlay');
  const isLoggedIn = sessionStorage.getItem('adminLoggedIn');

  if (!isLoggedIn) {
    overlay.style.display = 'flex';
  } else {
    overlay.style.display = 'none';
    loadDashboard();
  }

  document.getElementById('loginForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const user = this.username.value;
    const pass = this.password.value;
    const error = document.getElementById('loginError');

    if (user === ADMIN_CREDENTIALS.username && pass === ADMIN_CREDENTIALS.password) {
      sessionStorage.setItem('adminLoggedIn', 'true');
      overlay.style.display = 'none';
      loadDashboard();
      showToast('Welcome, Admin!');
    } else {
      error.style.display = 'block';
      error.textContent = 'Invalid username or password';
    }
  });
}

function adminLogout() {
  sessionStorage.removeItem('adminLoggedIn');
  window.location.reload();
}

function showAdminSection(sectionId) {
  document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
  document.getElementById(sectionId)?.classList.add('active');
  document.querySelectorAll('.admin-sidebar a').forEach(a => {
    a.classList.toggle('active', a.dataset.section === sectionId);
  });

  if (sectionId === 'dashboardSection') loadDashboard();
  if (sectionId === 'salesSection') loadSalesReport();
  if (sectionId === 'inventorySection') loadInventoryAdmin();
  if (sectionId === 'messagesSection') loadMessages();
}

function loadDashboard() {
  initProducts();
  initCustomers();
  const invoices = getData(STORAGE_KEYS.invoices, []);
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  const customers = getData(STORAGE_KEYS.customers, DEFAULT_CUSTOMERS);

  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalOrders = invoices.length;
  const lowStock = products.filter(p => p.stock < 100).length;

  document.getElementById('dashRevenue').textContent = formatCurrency(totalRevenue);
  document.getElementById('dashOrders').textContent = totalOrders;
  document.getElementById('dashCustomers').textContent = customers.length;
  document.getElementById('dashLowStock').textContent = lowStock;

  renderSalesChart(invoices);
  renderRecentOrders(invoices);
}

function renderSalesChart(invoices) {
  const chart = document.getElementById('salesChart');
  if (!chart) return;

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlySales = new Array(12).fill(0);

  invoices.forEach(inv => {
    const month = new Date(inv.date).getMonth();
    monthlySales[month] += inv.total;
  });

  const maxSale = Math.max(...monthlySales, 1);

  chart.innerHTML = monthlySales.map((val, i) => `
    <div class="chart-bar" style="height: ${(val / maxSale) * 100}%">
      <span class="bar-value">${val > 0 ? '₹' + Math.round(val / 1000) + 'K' : ''}</span>
      <span>${months[i]}</span>
    </div>
  `).join('');
}

function renderRecentOrders(invoices) {
  const tbody = document.getElementById('recentOrdersBody');
  if (!tbody) return;

  const recent = [...invoices].reverse().slice(0, 5);
  tbody.innerHTML = recent.length ? recent.map(inv => `
    <tr>
      <td>${inv.number}</td>
      <td>${inv.customerName}</td>
      <td>${formatCurrency(inv.total)}</td>
      <td>${inv.date}</td>
      <td><span class="badge badge-success">${inv.status}</span></td>
    </tr>
  `).join('') : '<tr><td colspan="5" style="text-align:center;">No orders yet</td></tr>';
}

function loadSalesReport() {
  const tbody = document.getElementById('salesReportBody');
  if (!tbody) return;

  const invoices = getData(STORAGE_KEYS.invoices, []).reverse();
  tbody.innerHTML = invoices.length ? invoices.map(inv => `
    <tr>
      <td>${inv.number}</td>
      <td>${inv.date}</td>
      <td>${inv.customerName}</td>
      <td>${inv.items.length}</td>
      <td>${formatCurrency(inv.subtotal)}</td>
      <td>${formatCurrency(inv.cgst + inv.sgst)}</td>
      <td>${formatCurrency(inv.total)}</td>
    </tr>
  `).join('') : '<tr><td colspan="7" style="text-align:center;">No sales data</td></tr>';
}

function loadInventoryAdmin() {
  const tbody = document.getElementById('inventoryBody');
  if (!tbody) return;

  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  tbody.innerHTML = products.map(p => `
    <tr>
      <td>${p.id}</td>
      <td>${p.emoji || '🫓'} ${p.name}</td>
      <td>${p.category}</td>
      <td>${formatCurrency(p.price)}</td>
      <td class="${p.stock < 100 ? 'badge-danger' : ''}">${p.stock}</td>
      <td>
        <button class="btn btn-secondary btn-sm" onclick="updateStock('${p.id}')">
          <i class="fa-solid fa-boxes-stacked"></i> Update
        </button>
      </td>
    </tr>
  `).join('');
}

function updateStock(productId) {
  const products = getData(STORAGE_KEYS.products, DEFAULT_PRODUCTS);
  const product = products.find(p => p.id === productId);
  if (!product) return;

  const newStock = prompt(`Update stock for ${product.name} (current: ${product.stock}):`, product.stock);
  if (newStock !== null && !isNaN(newStock)) {
    product.stock = parseInt(newStock);
    saveData(STORAGE_KEYS.products, products);
    loadInventoryAdmin();
    showToast('Stock updated');
  }
}

function loadMessages() {
  const tbody = document.getElementById('messagesBody');
  if (!tbody) return;

  const messages = getData(STORAGE_KEYS.contactMessages, []).reverse();
  tbody.innerHTML = messages.length ? messages.map(m => `
    <tr>
      <td>${new Date(m.date).toLocaleDateString('en-IN')}</td>
      <td>${m.name}</td>
      <td>${m.email}</td>
      <td>${m.subject}</td>
      <td>${m.message.substring(0, 50)}${m.message.length > 50 ? '...' : ''}</td>
    </tr>
  `).join('') : '<tr><td colspan="5" style="text-align:center;">No messages</td></tr>';
}

function exportSalesExcel() {
  const invoices = getData(STORAGE_KEYS.invoices, []);
  if (!invoices.length) { showToast('No data to export', 'error'); return; }

  let csv = 'Invoice No,Date,Customer,Subtotal,GST,Total\n';
  invoices.forEach(inv => {
    csv += `${inv.number},${inv.date},${inv.customerName},${inv.subtotal},${inv.cgst + inv.sgst},${inv.total}\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'appalam_sales_report.csv';
  a.click();
  URL.revokeObjectURL(url);
  showToast('Sales report exported!');
}

/* ===== Page Initialization ===== */
document.addEventListener('DOMContentLoaded', function() {
  setActiveNav();
  initMobileMenu();
  initProducts();
  initCustomers();

  const page = document.body.dataset.page;
  switch (page) {
    case 'home': initHomePage(); break;
    case 'products': initProductsPage(); break;
    case 'invoice': initInvoicePage(); break;
    case 'customers': initCustomersPage(); break;
    case 'contact': initContactPage(); break;
    case 'admin': initAdminPage(); break;
  }
});
